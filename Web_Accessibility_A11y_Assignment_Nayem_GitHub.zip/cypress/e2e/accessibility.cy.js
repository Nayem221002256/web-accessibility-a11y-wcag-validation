function saveReport(page, violations) {
  const summary = violations.map(({ id, impact, help, helpUrl, nodes }) => ({
    rule: id,
    impact,
    help,
    helpUrl,
    affectedNodes: nodes.length,
    selectors: nodes.map(node => node.target)
  }))

  cy.task('saveA11yReport', {
    page,
    generatedAt: new Date().toISOString(),
    violationCount: violations.length,
    violations: summary
  })

  cy.task('table', summary)
}

describe('WCAG Accessibility Automation', () => {
  it('scans the intentionally vulnerable page and records violations', () => {
    cy.visit('/vulnerable.html')
    cy.injectAxe()

    cy.checkA11y(
      null,
      {
        runOnly: {
          type: 'tag',
          values: ['wcag2a', 'wcag2aa']
        },
        includedImpacts: ['critical', 'serious', 'moderate', 'minor']
      },
      (violations) => saveReport('vulnerable', violations),
      true
    )
  })

  it('passes the automated scan on the remediated page', () => {
    cy.visit('/accessible.html')
    cy.injectAxe()
    cy.checkA11y(null, {
      runOnly: {
        type: 'tag',
        values: ['wcag2a', 'wcag2aa']
      }
    })
  })

  it('checks important accessibility attributes explicitly', () => {
    cy.visit('/accessible.html')
    cy.get('main').should('exist')
    cy.get('img[alt]').should('have.attr', 'alt').and('not.be.empty')
    cy.get('label[for="email"]').should('exist')
    cy.get('#email').should('have.attr', 'aria-describedby', 'email-help')
    cy.get('button[aria-label="Open menu"]').should('exist')
  })
})
