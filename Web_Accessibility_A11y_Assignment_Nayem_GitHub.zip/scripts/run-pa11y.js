const fs = require('fs')
const path = require('path')
const pa11y = require('pa11y')

const urls = [
  ['vulnerable', 'http://localhost:4173/vulnerable.html'],
  ['accessible', 'http://localhost:4173/accessible.html']
]

async function main() {
  fs.mkdirSync(path.join(__dirname, '..', 'reports'), { recursive: true })

  for (const [name, url] of urls) {
    const results = await pa11y(url, {
      runner: ['axe', 'htmlcs'],
      standard: 'WCAG2AA',
      timeout: 60000,
      includeWarnings: true
    })

    const out = path.join(__dirname, '..', 'reports', `pa11y-${name}.json`)
    fs.writeFileSync(out, JSON.stringify(results, null, 2))
    console.log(`${name}: ${results.issues.length} issues; saved to ${out}`)
  }
}

main().catch(error => {
  console.error(error)
  process.exit(1)
})
