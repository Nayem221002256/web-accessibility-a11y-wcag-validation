const http = require('http')
const fs = require('fs')
const path = require('path')

const root = path.join(__dirname, '..', 'public')
const port = 4173
const mime = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8'
}

const server = http.createServer((req, res) => {
  const requested = req.url === '/' ? '/accessible.html' : req.url
  const filePath = path.join(root, requested.split('?')[0])

  if (!filePath.startsWith(root) || !fs.existsSync(filePath)) {
    res.writeHead(404, { 'Content-Type': 'text/plain' })
    return res.end('Not Found')
  }

  const ext = path.extname(filePath)
  res.writeHead(200, { 'Content-Type': mime[ext] || 'application/octet-stream' })
  fs.createReadStream(filePath).pipe(res)
})

server.listen(port, () => {
  console.log(`A11Y demo server running at http://localhost:${port}`)
})
