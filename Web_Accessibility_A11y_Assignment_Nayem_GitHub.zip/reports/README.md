# Generated Reports

Run the test suite to generate JSON accessibility reports in this folder.

- Cypress + axe-core: `npm test`
- Pa11y: `npm run pa11y`
- Both: `npm run accessibility`

The vulnerable page is intentionally defective so the automation can demonstrate detection. The remediated page is designed to pass the automated checks.
