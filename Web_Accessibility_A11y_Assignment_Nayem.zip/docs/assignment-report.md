# Web Accessibility (a11y) Automation & WCAG Compliance Validation

**Student:** Md. Nayem Ibne Nur  
**Student ID:** 221002256  
**Section:** 223 D1  

## Abstract

Web accessibility ensures that websites can be perceived, understood, navigated, and operated by people with different abilities and assistive technologies. This assignment presents an automated accessibility validation workflow using Cypress, axe-core, and Pa11y. A deliberately vulnerable demo webpage is compared with a remediated version. Cypress integrates axe-core into end-to-end tests to detect WCAG-related violations, while Pa11y provides an independent accessibility audit. The system records detected issues, their impact, affected elements, and remediation guidance. The project demonstrates how accessibility checks can be integrated into software testing and continuous quality assurance.

## 1. Introduction

Modern web applications must support a wide range of users, including people who use screen readers, keyboard navigation, magnification, voice control, or other assistive technologies. Accessibility problems such as missing alternative text, unlabeled form controls, inaccessible buttons, poor color contrast, and incorrect document structure can prevent users from completing tasks.

Manual accessibility auditing is valuable but time-consuming. Automated accessibility testing can be integrated into regular browser tests so that common issues are detected earlier in development. Cypress documentation recommends combining automated scans with application-specific accessibility assertions and manual testing because automation cannot detect every accessibility problem.

## 2. Problem Statement

A development team needs a repeatable way to identify common accessibility defects and validate that fixes do not introduce new WCAG-related problems. The solution should run automatically, produce actionable results, and be suitable for integration into a software testing workflow.

## 3. Objectives

1. Build an automated accessibility testing workflow.
2. Integrate axe-core with Cypress.
3. Validate pages against common WCAG 2A/2AA rules.
4. Use Pa11y as an additional validation tool.
5. Record accessibility violations in machine-readable reports.
6. Demonstrate remediation by comparing vulnerable and accessible pages.
7. Show the limitations of automated accessibility testing.

## 4. Tools and Technologies

### Cypress

Cypress is used as the browser-based end-to-end testing framework. It loads the target page, injects the accessibility engine, and executes automated assertions.

### axe-core

axe-core is an open-source accessibility testing engine. In this project, it is integrated through the `cypress-axe` plugin. The scan reports violations with rule IDs, impact levels, descriptions, help links, and affected DOM nodes.

### cypress-axe

`cypress-axe` provides Cypress commands such as `cy.injectAxe()` and `cy.checkA11y()` for running axe-core checks inside Cypress tests.

### Pa11y

Pa11y is used as a second automated accessibility validator. It can run from the command line or Node.js and supports both HTML_CodeSniffer and axe runners.

### Node.js

Node.js and npm provide the project runtime and dependency management.

## 5. System Architecture

The workflow is:

**Demo Web Page → Cypress → cypress-axe → axe-core → WCAG Rules → Violation Report**

A second path is:

**Demo Web Page → Pa11y → axe/HTMLCS → WCAG 2AA Audit → JSON Report**

The project compares an intentionally vulnerable page with a remediated page. This makes the assignment demonstrable without depending on a third-party website that may change over time.

## 6. Implementation

### 6.1 Vulnerable page

The vulnerable page intentionally contains several common defects:

- no `lang` attribute on the root HTML element;
- image without `alt` text;
- icon-only buttons without an accessible name;
- email input without a programmatic label;
- low-contrast text;
- heading hierarchy that skips the expected structure;
- content outside a semantic `main` landmark.

### 6.2 Remediated page

The accessible page applies fixes including:

- `lang="en"` on the document;
- meaningful alternative text for the image;
- `aria-label` on the icon-only menu button;
- a `<label for="email">` associated with the input;
- improved foreground/background contrast;
- semantic `main` and `section` landmarks;
- clearer heading hierarchy;
- visible keyboard focus styles.

### 6.3 Cypress test

The test first visits the vulnerable page, calls `cy.injectAxe()`, and executes `cy.checkA11y()`. Violations are captured and written to JSON. The check uses WCAG 2A and 2AA tags and includes all impact levels.

The second test visits the remediated page and expects the automated accessibility scan to pass.

An additional test explicitly verifies important accessibility attributes such as image alternative text, form labels, `aria-describedby`, and the accessible name of the menu button.

### 6.4 Pa11y test

Pa11y is configured to audit both pages using WCAG2AA. It can use both the axe and HTML_CodeSniffer runners. Results are saved as JSON for later review.

## 7. Test Cases

| Test Case | Page | Expected Result |
|---|---|---|
| TC-01 | Vulnerable page | Violations detected and saved |
| TC-02 | Accessible page | Automated scan passes |
| TC-03 | Accessible image | Non-empty `alt` attribute exists |
| TC-04 | Email field | Programmatic label exists |
| TC-05 | Email help text | `aria-describedby` references help text |
| TC-06 | Menu button | Accessible name exists |
| TC-07 | Pa11y vulnerable audit | Issues reported |
| TC-08 | Pa11y accessible audit | Fewer/no blocking issues expected |

## 8. Expected Findings

The vulnerable page is designed to trigger common accessibility rules. Exact counts can vary by the versions of axe-core, browser engine, and Pa11y runner used. Therefore, the generated JSON files in `reports/` should be treated as the authoritative run output.

Typical findings include image alternative text, button naming, form labeling, document language, landmarks/structure, and color contrast.

## 9. Result Analysis

The project demonstrates the difference between detection and remediation. On the vulnerable page, automated testing should identify multiple issues and provide rule-level information. After the HTML is corrected, the same automated test suite should report a clean or substantially improved result.

The report output can be used by developers to locate the affected element and understand the remediation needed. Because automated rules have limited coverage, a clean automated result does not mean that the application is fully accessible.

## 10. Accessibility Compliance Strategy

A practical accessibility quality strategy should include:

1. automated axe-core checks in browser tests;
2. Pa11y or another independent scanner for cross-validation;
3. explicit Cypress assertions for application-specific accessibility behavior;
4. keyboard-only testing;
5. screen-reader testing;
6. manual review of content, focus order, error messages, and dynamic interactions;
7. regression testing after fixes.

## 11. Limitations

Automated accessibility testing cannot fully replace human evaluation. Some issues depend on meaning, context, interaction behavior, focus management, screen-reader output, or real user experience. The project therefore treats automated scanning as an important quality gate rather than proof of complete WCAG conformance.

## 12. Conclusion

This assignment implemented a repeatable accessibility validation workflow using Cypress, axe-core, and Pa11y. The vulnerable and remediated pages demonstrate how automated tools can identify common accessibility problems and verify improvements. The approach can be extended to real applications and CI pipelines, where accessibility checks can run automatically whenever code changes are introduced.

## 13. References

1. Cypress Documentation — Accessibility Testing: https://docs.cypress.io/app/guides/accessibility-testing
2. cypress-axe — GitHub: https://github.com/component-driven/cypress-axe
3. axe-core — npm: https://www.npmjs.com/package/axe-core
4. Pa11y — npm: https://www.npmjs.com/package/pa11y
5. W3C — Web Content Accessibility Guidelines (WCAG) 2.2: https://www.w3.org/TR/WCAG22/
